import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("Data/Electric_Vehicle_Population_Data.csv")
print("✅ Dataset Loaded Successfully!")
print("Shape of Dataset:", df.shape)

print("\n--- Dataset Information ---")
df.info()

print("\n--- Summary Statistics ---")
print(df.describe())


print("\n--- Columns Available ---")
print(df.columns)

print("\n--- Missing Values ---")
print(df.isnull().sum())

df.drop_duplicates(inplace=True)

df = df.dropna(subset=['Electric Range', 'Model Year', 'Make'])

df['Model Year'] = df['Model Year'].astype(int)


print("\n✅ After Cleaning:")
print(df.shape)
print(df.isnull().sum())

print("\nUnique EV Manufacturers:", df['Make'].nunique())
print("Unique EV Types:", df['Electric Vehicle Type'].unique())

plt.figure(figsize=(10,5))
df['Make'].value_counts().head(10).plot(kind='bar', color='skyblue')
plt.title('Top 10 Electric Vehicle Manufacturers')
plt.xlabel('Manufacturer')
plt.ylabel('Number of Vehicles')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()


plt.figure(figsize=(10,5))
df['Model Year'].value_counts().sort_index().plot(kind='line', marker='o', color='green')
plt.title('Electric Vehicle Adoption by Model Year')
plt.xlabel('Year')
plt.ylabel('Number of Vehicles')
plt.grid(True)
plt.show()


plt.figure(figsize=(10,5))
sns.histplot(df['Electric Range'], bins=30, kde=True, color='purple')
plt.title('Electric Vehicle Range Distribution')
plt.xlabel('Electric Range (miles)')
plt.ylabel('Frequency')
plt.show()


plt.figure(figsize=(6,5))
df['Electric Vehicle Type'].value_counts().plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=['#00c1d4','#ffb347'])
plt.title('Electric Vehicle Type Distribution')
plt.ylabel('')
plt.show()

plt.figure(figsize=(8,5))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap Between Numeric Features')
plt.show()

plt.figure(figsize=(8,5))
sns.scatterplot(x='Model Year', y='Electric Range', hue='Electric Vehicle Type', data=df)
plt.title('Model Year vs Electric Range')
plt.xlabel('Model Year')
plt.ylabel('Electric Range')
plt.legend()
plt.show()

df.to_csv("Cleaned_Electric_Vehicle_Data.csv", index=False)
print("\n✅ Cleaned dataset saved as 'Cleaned_Electric_Vehicle_Data.csv'")


